#token = '6018194893:AAGvOsGPl6GscqKSjhe2LbyYGpIKXgv5E0A'
token = '6051663493:AAFlwL5Jb61gM-wWMwls1F1fOxKV5RFlavE'
first_message = "Здравствуйте, для расчета оптимального ассортимента питания и создания персонального меню, пожалуйста нажмите кнопку 'Советы по питанию'"
java_app_path = "data\\bot.jar"
import telebot
from telebot import types
from bot_settings import token, first_message, java_app_path
import subprocess

bot = telebot.TeleBot(token)

def start_message(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    advice_button = types.KeyboardButton('Советы по питанию')
    markup.add(advice_button)
    bot.send_message(message.chat.id, first_message, reply_markup=markup)

def handle_advice_request(message):
    global genderMale
    genderMale = False
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    genderM_button = types.KeyboardButton('Мужской')
    genderG_button = types.KeyboardButton('Женский')
    markup.add(genderM_button, genderG_button)
    bot.send_message(message.chat.id, "Выберете свой пол", reply_markup=markup)


def handle_age_request(message):
    bot.send_message(message.chat.id, "Введите свой возраст", reply_markup=types.ReplyKeyboardRemove())
    bot.register_next_step_handler(message, handle_age)

def handle_age(message):
    global age
    try:
        age = int(message.text)
        if age <= 0:
            bot.send_message(message.chat.id, "Некорректно введен возраст. Пожалуйста, введите положительное число.")
            bot.register_next_step_handler(message, handle_age)
            return
        bot.send_message(message.chat.id, "Введите свой рост")
        bot.register_next_step_handler(message, handle_height)
    except ValueError:
        bot.send_message(message.chat.id, "Некорректно введен возраст. Пожалуйста, введите число.")
        bot.register_next_step_handler(message, handle_age)

def handle_height(message):
    global height
    try:
        height = int(message.text)
        if height <= 0:
            bot.send_message(message.chat.id, "Некорректно введен рост. Пожалуйста, введите положительное число.")
            bot.register_next_step_handler(message, handle_height)
            return
        bot.send_message(message.chat.id, "Введите свой вес")
        bot.register_next_step_handler(message, handle_weight)
    except ValueError:
        bot.send_message(message.chat.id, "Некорректно введен рост. Пожалуйста, введите число.")
        bot.register_next_step_handler(message, handle_height)

def handle_weight(message):
    global weight
    try:
        weight = int(message.text)
        if weight <= 0:
            bot.send_message(message.chat.id, "Некорректно введен вес. Пожалуйста, введите положительное число.")
            bot.register_next_step_handler(message, handle_weight)
            return
        handle_activity_level_request(message)
    except ValueError:
        bot.send_message(message.chat.id, "Некорректно введен вес. Пожалуйста, введите число.")
        bot.register_next_step_handler(message, handle_weight)

def handle_activity_level_request(message):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        level1 = types.KeyboardButton('Малоподвижный')
        level2 = types.KeyboardButton('Низкая активность')
        level3 = types.KeyboardButton('Умеренная активность')
        level4 = types.KeyboardButton('Высокая активность')
        level5 = types.KeyboardButton('Очень высокая активность')
        markup.add(level1, level2, level3, level4, level5)
        bot.send_message(message.chat.id, "Выберите ваш уровень физической активности", reply_markup=markup)
        bot.register_next_step_handler(message, handle_activity)

def handle_activity(message):
    global activity_level
    if message.text == 'Малоподвижный':
        activity_level = 1
    elif message.text == 'Низкая активность':
        activity_level = 2
    elif message.text == 'Умеренная активность':
        activity_level = 3
    elif message.text == 'Высокая активность':
        activity_level = 4
    elif message.text == 'Очень высокая активность':
        activity_level = 5
    else:
        bot.send_message(message.chat.id, 'Некорректно введен уровень физической активности')
        handle_activity_level_request(message)
    if genderMale == True:
        gender = 'M'
    else:
        gender = 'W'
    java_main(gender, height, weight, age, activity_level, message)

    back = types.KeyboardButton("Назад")
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(back)
    bot.send_message(message.chat.id, 'Для возвращение в основное меню нажмите "Назад"', reply_markup=markup)



@bot.message_handler(func=lambda message: message.text == 'Назад')
def back_command(message):
    start_message(message)
@bot.message_handler(commands=["start"])
def start(message):
    start_message(message)

@bot.message_handler(func=lambda message: message.text == 'Советы по питанию')
def handle_advise(message):
    handle_advice_request(message)

@bot.message_handler(func=lambda message: message.text == 'Мужской' or message.text == 'Женский')
def handle_gender_request(message):
    global genderMale
    if message.text == 'Мужской':
        genderMale = True
    else:
        genderMale = False
    handle_age_request(message)

def java_main(gender, height, weight, age, activity_level,message):
    height = str(height)
    weight = str(weight)
    age = str(age)
    activity_level = str(activity_level)
    parametrs = gender+ ' ' + height + ' ' + weight + ' ' + age + ' ' + activity_level
    print(parametrs)
    process = subprocess.Popen(["java", "-jar", java_app_path], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    input_data = parametrs
    process.stdin.write(input_data.encode())
    process.stdin.flush()

    # Получаем выходные данные из процесса
    output, error = process.communicate()
    #print(error)
    # Выводим полученные данные в консоль
    result = output.decode('cp1251')
    print(output.decode('cp1251'))
    bot.send_message(message.chat.id, result)

bot.polling(none_stop=True, interval=0)